<?php
// Configurações Gerais
$host = "localhost";
$user = "root";
$pass = "";
$database = "nota1000";
$connection = mysql_connect($host, $user, $pass) or die (mysql_error());
mysql_select_db($database) or die (mysql_error());
// Declaração dos Namespaces dos Controladores & Instanciação dos Objetos
use Project\Controller\Controller;
$Controller = new Controller();