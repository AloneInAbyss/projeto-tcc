<?php
// Rotas da Aplicação

// A Variável '$uri' Contém os Dados da Rota Solicitada
switch ($uri) {
    
    case '/':
        $Controller->paginainicial();
        break;

    case '/resultado':
        $Controller->resultado();
        break;    

    /*case '/sobre-nos':
        $Controller->sobrenos();
        break;*/

    case '/materia-matematica':
        $Controller->materiamatematica();
        break;

    case '/materia-quimica':
    case '/materia-fisica':
    case '/materia-biologia':
    case '/materia-geografia':
    case '/materia-historia':
    case '/materia-portugues':
    case '/materia-literatura':
        $Controller->materias();
        break;

    case '/conteudos':
        $Controller->conteudos();
        break;

    case '/exercicios':
        $Controller->exercicios();
        break;
        
    default:
        $Controller->erro404();
        break;
}
