<?php
// Configurações Gerais

// Declaração dos Namespaces dos Controladores & Instanciação dos Objetos
use Project\Controller\Controller;
$Controller = new Controller();