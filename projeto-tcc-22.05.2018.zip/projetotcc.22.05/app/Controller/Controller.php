<?php

namespace Project\Controller;

class Controller
{
    public function paginainicial()
    {
        require './app/views/pagina-inicial.php';
    }

    public function materias()
    {
        require './app/views/modelo-materia.php';
    }

    public function conteudos()
    {
        require './app/views/modelo-pagina-materia.php';
    }

    public function exercicios()
    {
        require './app/views/modelo-exercicios.php';
    }

    public function erro404()
    {
        require './app/views/erro404.php';
    }
}
