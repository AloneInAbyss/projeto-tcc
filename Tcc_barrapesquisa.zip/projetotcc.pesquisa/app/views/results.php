<!DOCTYPE html>
<?php
include "config.php";
?>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- BOOTSTRAP CSS, ESTILOS PERSONALIZADOS -->
    <link rel="stylesheet" href="/public/bootstrap/css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="/public/css/style.css">
    <link rel="stylesheet" href="/public/css/pagina-inicial.css">

    <!-- TÍTULO & ÍCONE DO SITE -->
    <title>NOTA 1000 - Página Inicial</title>
    <link rel="icon" href="/public/images/site-logo.png">

    <!-- GOOGLE FONT -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <!-- BOTÃO/ÍCONE DA NAVBAR -->
      <a class="navbar-brand" href="/">NOTA1000</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- LINKS DA NAVBAR -->
      <div class="collapse navbar-collapse" id="navbar">
        <ul class="navbar-nav mr-auto">

          <!-- LINK 'PÁGINA INICIAL' -->
          <li class="nav-item active">
            <a class="nav-link" href="/">Página Inicial</a>
          </li>

          <!-- LINK 'SOBRE NÓS' -->
          <li class="nav-item">
            <a class="nav-link" href="/sobre-nos">Sobre Nós</a>
          </li>

          <!-- DROPDOWN -->
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Matérias</a>
            <div class="dropdown-menu" aria-labelledby="dropdown01">
              <a class="dropdown-item" href="/materia-matematica">Matemática</a>
              <a class="dropdown-item" href="/materia-fisica">Física</a>
              <a class="dropdown-item" href="/materia-quimica">Química</a>
              <a class="dropdown-item" href="/materia-biologia">Biologia</a>
              <a class="dropdown-item" href="/materia-geografia">Geografia</a>
              <a class="dropdown-item" href="/materia-historia">História</a>
              <a class="dropdown-item" href="/materia-portugues">Português</a>
              <a class="dropdown-item" href="/materia-filosofia">Filosofia</a>
            </div>
          </li>
        </ul>

        <!-- FORMULÁRIO 'PESQUISA' -->
        <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="text" placeholder="Pesquisar" aria-label="Pesquisa">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Pesquisar</button>
        </form>

      </div>
      <!-- /LINKS DA NAVBAR -->
    </nav>
    <!-- /NAVBAR -->

    <!-- CONTEÚDO DA PÁGINA -->
    <main role="main">    
        <!-- CONTAINER -->
        <div class="container">
            <p><?php
                $buscar=$_POST['buscar'];
                $sql = mysql_query("select * from resumos WHERE resumo LIKE '%".$buscar."%' OR nome LIKE '%".$buscar."%' OR 
                 materia LIKE '%".$buscar."%' OR submateria LIKE '%".$buscar."%' ");
                $row = mysql_num_rows($sql);
                if($row > 0) {
                    while($linha = mysql_fetch_array($sql)){
                        $link = $linha['link'];
                        $nome = $linha['nome'];
                        $materia = $linha['materia'];
                        $submateria = $linha['submateria'];
                        $descricao = $linha['descricao'];
                        echo '<br>';
                        ?><a href="<?php echo $link; ?>"<p><?php echo $nome ?></p></a><?php 
                        echo $materia;
                        echo '<br>';
                        echo $submateria;
                        echo '<br>';
                        echo $descricao;
                        echo '<br>';
                    }
                }
                else{
                    echo "Desculpe, nenhum resumo foi encontrado!";
                }
            ?></p>
            <!-- /SEÇÃO - LINKS PARA MATÉRIAS -->

            <hr class="linha-divisoria">
        </div>
        <!-- /CONTAINER -->

        <!-- RODAPÉ -->
        <footer class="container">
            <p class="float-right"><a href="#">Voltar para Cima</a></p>
            <p>&copy; 2018 Nota1000, 3º ETIM INFORMÁTICA &middot; <a href="/sobre-nos">Sobre Nós</a></p>
        </footer>
        <!-- /RODAPÉ -->
    </main>
    <!-- /CONTEÚDO DA PÁGINA -->

    <!-- BOOTSTRAP JQUERY, POPPER & JAVASCRIPT -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="/public/bootstrap/js/bootstrap.min.js" crossorigin="anonymous"></script>
</body>
</html>