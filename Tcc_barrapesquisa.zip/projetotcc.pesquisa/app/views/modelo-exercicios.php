<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- BOOTSTRAP CSS -->
    <link rel="stylesheet" href="/public/bootstrap/css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="/public/css/style.css">
    
    <!-- TÍTULO & ÍCONE DO SITE -->

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

    <title>NOTA 1000 - Modelo de Conteúdo da Matéria</title>
    <link rel="icon" href="">
    <script>
    var
    r = 0;
    z = 0;
        function clicar(x){
            document.getElementById("confirm"+x).style.display = "block";
            r = x + 0;
            /* document.getElementById("result"+x).style.display = "block";*/
        }

        function resposta(y){
           z = y + 0; 
        }

        function avaliar1(){ 
           if (z==0){
               document.getElementsByName("gender")[0].style.backgroundColor = "green";
               document.getElementById("result"+r).style.display = "block";
           }
           else{
            document.getElementsByName("gender")[0].style.backgroundColor = "green";
            document.getElementsByName("gender")[z].style.backgroundColor = "red";
            document.getElementById("result"+r).style.display = "block";
           }
        }
        
        function avaliar2(){
           if (z==5){
               document.getElementsByName("gender")[5].style.backgroundColor = "green";
               document.getElementById("result"+r).style.display = "block";
           }
           else{
            document.getElementsByName("gender")[5].style.backgroundColor = "green";
            document.getElementsByName("gender")[z].style.backgroundColor = "red";
            document.getElementById("result"+r).style.display = "block";
           }
        }

        function avaliar3(){
           if (z==10){
               document.getElementsByName("gender")[10].style.backgroundColor = "green";
               document.getElementById("result"+r).style.display = "block";
           }
           else{
            document.getElementsByName("gender")[10].style.backgroundColor = "green";
            document.getElementsByName("gender")[z].style.backgroundColor = "red";
            document.getElementById("result"+r).style.display = "block";
           }
        }

        function avaliar4(){
           if (z==15){
               document.getElementsByName("gender")[15].style.backgroundColor = "green";
               document.getElementById("result"+r).style.display = "block";
           }
           else{
            document.getElementsByName("gender")[15].style.backgroundColor = "green";
            document.getElementsByName("gender")[z].style.backgroundColor = "red";
            document.getElementById("result"+r).style.display = "block";
           }
        }

        function avaliar5(){
           if (z==20){
               document.getElementsByName("gender")[20].style.backgroundColor = "green";
               document.getElementById("result"+r).style.display = "block";
           }
           else{
            document.getElementsByName("gender")[20].style.backgroundColor = "green";
            document.getElementsByName("gender")[z].style.backgroundColor = "red";
            document.getElementById("result"+r).style.display = "block";
           }

        function show(){
            document.getElementById("caixa1").style.display = "block";
        }

        }
    </script>
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
      <!-- BOTÃO/ÍCONE DA NAVBAR -->
      <a class="navbar-brand" href="/">NOTA1000</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- LINKS DA NAVBAR -->
      <div class="collapse navbar-collapse" id="navbar">
        <ul class="navbar-nav mr-auto">

          <!-- LINK 'PÁGINA INICIAL' -->
          <li class="nav-item">
            <a class="nav-link" href="/">Página Inicial</a>
          </li>

          <!-- LINK 'SOBRE NÓS' -->
          <li class="nav-item">
            <a class="nav-link" href="#">Sobre Nós</a>
          </li>

          <!-- DROPDOWN -->
          <li class="nav-item dropdown active">
            <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Matérias</a>
            <div class="dropdown-menu" aria-labelledby="dropdown01">
              <a class="dropdown-item active" href="#">(Matéria Atual) <span class="sr-only">(current)</span></a>
              <a class="dropdown-item" href="/materia-matematica">Matemática</a>
              <a class="dropdown-item" href="/materia-fisica">Física</a>
              <a class="dropdown-item" href="/materia-quimica">Química</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="/materia-biologia">Biologia</a>
              <a class="dropdown-item" href="/materia-geografia">Geografia</a>
              <a class="dropdown-item" href="/materia-historia">História</a>
            </div>
          </li>
        </ul>

        <!-- FORMULÁRIO 'PESQUISA' -->
        <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="text" placeholder="Pesquisar" aria-label="Pesquisa">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Pesquisar</button>
        </form>

      </div>
      <!-- /LINKS DA NAVBAR -->
    </nav>
    <!-- /NAVBAR -->

    <!-- CONTEÚDO DA PÁGINA -->
    <main role="main">    
        <!-- CONTAINER -->
        <div class="container marketing" style="padding-top: 50px;">

            <!-- BREADCRUMP -->
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/">Início</a></li>
                    <li class="breadcrumb-item"><a href="#">(Matéria)</a></li>
                    <li class="breadcrumb-item"><a href="#">(Tema)</a></li>
                    <li class="breadcrumb-item active" aria-current="page">(Exercicios)</li>
                </ol>
            </nav>
            

            <!-- TÍTULO DA PÁGINA -->
            <h1>(Exercicios 'Nome da materia')</h1>
            <h3 class="text-muted">('Nome do Tema')</h3>
            <hr class="page-header" style="padding-bottom: 15px">

            <div class="row">
                    <div class="col-sm-8">
                        <p>1-)(MACKIENZE-SP) Um elevador caiu numa velocidade de 300 m/s por segundo quem foi o culpado?</p>
                        <div id="caixa1" class="float div-ocultar" style="display:none">
                <p class="my-float">Gostária de testar seu conhecimento?</p>
                <br>
                <a href="/exercicio"<button type="button" class="btn btn-outline-danger button-float">Clique Aqui!</button></a>
            </div>
                        <input type="radio" class="option-input radio" name="gender" value="correta" onclick="clicar(1);resposta(0)"> Alternativa 1<br>
                        <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(1);resposta(1)"> Alternativa 2<br>
                        <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(1);resposta(2)"> Alternativa 3<br>
                        <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(1);resposta(3)"> Alternativa 4<br>
                        <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(1);resposta(4)"> Alternativa 5<br>   
                        </br>               
                        <button id="confirm1" type="button" class="btn btn-outline-danger button-float" style="display:none" onclick="avaliar1()">Confirmar</button>
                        <button id="result1" type="button" class="btn btn-outline-danger button-float" style="display:none" onclick="show()">Resolução</button>
                    </div>
                </div>

            <hr class="featurette-divider">

            <div class="row">
            <div class="col-sm-8">
                <p>1-)(MACKIENZE-SP) Um elevador caiu numa velocidade de 300 m/s por segundo quem foi o culpado?</p>
                <input type="radio" class="option-input radio" name="gender" value="correta" onclick="clicar(2);resposta(5)"> Alternativa 1<br>
                <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(2);resposta(6)"> Alternativa 2<br>
                <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(2);resposta(7)"> Alternativa 3<br>
                <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(2);resposta(8)"> Alternativa 4<br>
                <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(2);resposta(9)"> Alternativa 5<br>   
                </br>               
                <button id="confirm2" type="button" class="btn btn-outline-danger button-float" style="display:none" onclick="avaliar2()">Confirmar</button>
                <button id="result2" type="button" class="btn btn-outline-danger button-float" style="display:none">Resolução</button>
            </div>
        </div>
            

            <hr class="featurette-divider">

            <div class="row">
            <div class="col-sm-8">
                <p>1-)(MACKIENZE-SP) Um elevador caiu numa velocidade de 300 m/s por segundo quem foi o culpado?</p>
                <input type="radio" class="option-input radio" name="gender" value="correta" onclick="clicar(3);resposta(10)"> Alternativa 1<br>
                <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(3);resposta(11)"> Alternativa 2<br>
                <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(3);resposta(12)"> Alternativa 3<br>
                <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(3);resposta(13)"> Alternativa 4<br>
                <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(3);resposta(14)"> Alternativa 5<br>   
                </br>               
                <button id="confirm3" type="button" class="btn btn-outline-danger button-float" style="display:none" onclick="avaliar3()">Confirmar</button>
                <button id="result3" type="button" class="btn btn-outline-danger button-float" style="display:none">Resolução</button>
            </div>
        </div>

                <hr class="featurette-divider">

                <div class="row">
                <div class="col-sm-8">
                    <p>1-)(MACKIENZE-SP) Um elevador caiu numa velocidade de 300 m/s por segundo quem foi o culpado?</p>
                    <input type="radio" class="option-input radio" name="gender" value="correta" onclick="clicar(4);resposta(15)"> Alternativa 1<br>
                    <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(4);resposta(16)"> Alternativa 2<br>
                    <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(4);resposta(17)"> Alternativa 3<br>
                    <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(4);resposta(18)"> Alternativa 4<br>
                    <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(4);resposta(19)"> Alternativa 5<br>   
                    </br>               
                    <button id="confirm4" type="button" class="btn btn-outline-danger button-float" style="display:none" onclick="avaliar4()">Confirmar</button>
                    <button id="result4" type="button" class="btn btn-outline-danger button-float" style="display:none">Resolução</button>
                </div>
            </div>

                <hr class="featurette-divider">

                <div class="row">
                <div class="col-sm-8">
                    <p>1-)(MACKIENZE-SP) Um elevador caiu numa velocidade de 300 m/s por segundo quem foi o culpado?</p>
                    <input type="radio" class="option-input radio" name="gender" value="correta" onclick="clicar(5);resposta(20)"> Alternativa 1<br>
                    <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(5);resposta(21)"> Alternativa 2<br>
                    <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(5);resposta(22)"> Alternativa 3<br>
                    <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(5);resposta(23)"> Alternativa 4<br>
                    <input type="radio" class="option-input radio" name="gender" value="errada" onclick="clicar(5);resposta(24)"> Alternativa 5<br>   
                    </br>               
                    <button id="confirm5" type="button" class="btn btn-outline-danger button-float" style="display:none" onclick="avaliar5()">Confirmar</button>
                    <button id="result5" type="button" class="btn btn-outline-danger button-float" style="display:none">Resolução</button>
                </div>
            </div>
        </div>
        <!-- /CONTAINER -->

            <!-- RODAPÉ -->
        <footer class="container">
            <p class="float-right"><a href="#">Voltar para Cima</a></p>
            <p>&copy; 2018 Nota1000, 3º ETIM INFORMÁTICA &middot; <a href="#">Sobre Nós</a></p>
        </footer>
        <!-- /RODAPÉ -->
    </main>
    <!-- /CONTEÚDO DA PÁGINA -->

    <!-- BOOTSTRAP JQUERY, POPPER & JAVASCRIPT -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="/public/bootstrap/js/bootstrap.min.js" crossorigin="anonymous"></script>
</body>
</html>