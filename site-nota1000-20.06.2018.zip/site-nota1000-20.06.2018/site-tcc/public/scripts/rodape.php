<?php
echo '
<!-- RODAPÉ -->
<footer class="container link">
    <p class="float-right"><a href="#">Voltar para Cima</a></p>
    <p>&copy; 2018 Nota1000, 3º ETIM INFORMÁTICA &middot; <a href="/sobre-nos">Sobre Nós</a></p>
</footer>
<!-- /RODAPÉ -->
';