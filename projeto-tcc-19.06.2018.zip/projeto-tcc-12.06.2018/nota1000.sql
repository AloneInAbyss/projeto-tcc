-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           5.5.5-10.1.13-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win32
-- HeidiSQL Versão:              7.0.0.4362
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Copiando estrutura do banco de dados para nota1000
CREATE DATABASE IF NOT EXISTS `nota1000` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `nota1000`;


-- Copiando estrutura para tabela nota1000.questao
CREATE TABLE IF NOT EXISTS `questao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resposta` varchar(255) DEFAULT NULL,
  `questao` varchar(255) DEFAULT NULL,
  `alternativa1` varchar(255) DEFAULT NULL,
  `alternativa2` varchar(255) DEFAULT NULL,
  `alternativa3` varchar(255) DEFAULT NULL,
  `alternativa4` varchar(255) DEFAULT NULL,
  `alternativa5` varchar(255) DEFAULT NULL,
  `resolucao` varchar(255) DEFAULT NULL,
  `materia` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela nota1000.questao: ~5 rows (aproximadamente)
/*!40000 ALTER TABLE `questao` DISABLE KEYS */;
INSERT INTO `questao` (`id`, `resposta`, `questao`, `alternativa1`, `alternativa2`, `alternativa3`, `alternativa4`, `alternativa5`, `resolucao`, `materia`) VALUES
	(1, 'Caio', 'Se o trabalho de TCC der ruim de quem é a culpa ?', 'Iago', 'Joel', 'Caio', 'Laura', 'Mariana', 'Blablalba wiska sache', 'matematica'),
	(2, 'Laura', 'Se o trabalho de TCC der ruim de quem é a culpa ?', 'Iago', 'Joel', 'Caio', 'Laura', 'Mariana', 'Blablalba wiska sache', 'matematica'),
	(3, 'Iago', 'Se o trabalho de TCC der ruim de quem é a culpa ?', 'Iago', 'Joel', 'Caio', 'Laura', 'Mariana', 'Blablalba wiska sache', 'matematica'),
	(4, 'Joel', 'Se o trabalho de TCC der ruim de quem é a culpa ?', 'Iago', 'Joel', 'Caio', 'Laura', 'Mariana', 'Blablalba wiska sache', 'matematica'),
	(5, 'Mariana', 'Se o trabalho de TCC der ruim de quem é a culpa ?', 'Iago', 'Joel', 'Caio', 'Laura', 'Mariana', 'Blablalba wiska sache', 'matematica');
/*!40000 ALTER TABLE `questao` ENABLE KEYS */;


-- Copiando estrutura para tabela nota1000.resumos
CREATE TABLE IF NOT EXISTS `resumos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `materia` varchar(255) DEFAULT NULL,
  `submateria` varchar(255) DEFAULT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `resumo` longtext,
  `link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela nota1000.resumos: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `resumos` DISABLE KEYS */;
INSERT INTO `resumos` (`id`, `nome`, `materia`, `submateria`, `descricao`, `resumo`, `link`) VALUES
	(1, 'Velocidade da onda', 'Ondulatoria', 'Propagação da onda', 'Blablablablablablabla wiska sache...', 'Velocidade da onda,Ondulatoria,Propagação da onda', '/conteudos'),
	(2, 'Velocidade da onda 2', 'Ondulatoria 2', 'Propagação da onda 2', 'Blablablablablablabla wiska sache...', 'Velocidade da onda,Ondulatoria,Propagação da onda 2', '/conteudos');
/*!40000 ALTER TABLE `resumos` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
