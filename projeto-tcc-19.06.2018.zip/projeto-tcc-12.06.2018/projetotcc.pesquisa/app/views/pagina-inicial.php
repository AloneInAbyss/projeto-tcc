<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- BOOTSTRAP CSS, ESTILOS PERSONALIZADOS -->
    <link rel="stylesheet" href="/public/bootstrap/css/bootstrap.min.css" crossorigin="anonymous">
    <!-- CSS -->
        <!-- CSS GERAL -->
        <link rel="stylesheet" href="/public/css/style.css">
        <!-- CSS DESSA PÁGINA ESPECÍFICA -->
        <link rel="stylesheet" href="/public/css/pagina-inicial.css">

    <!-- TÍTULO & ÍCONE DO SITE -->
    <title>NOTA 1000 - Página Inicial</title>
    <link rel="icon" href="/public/images/site-logo.png">
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <!-- BOTÃO/ÍCONE DA NAVBAR -->
      <a class="navbar-brand" href="/"><img alt="Logotipo" src="/public/images/logo.jpg"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- LINKS DA NAVBAR -->
      <div class="collapse navbar-collapse" id="navbar">
        <ul class="navbar-nav mr-auto">

          <!-- LINK 'PÁGINA INICIAL' -->
          <li class="nav-item">
            <a class="nav-link texto-branco" href="/">Página Inicial</a>
          </li>

          <!-- LINK 'SOBRE NÓS' -->
          <li class="nav-item">
            <a class="nav-link texto-branco" href="/sobre-nos">Sobre Nós</a>
          </li>

          <!-- DROPDOWN -->
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle texto-branco" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Matérias</a>
            <div class="dropdown-menu" aria-labelledby="dropdown01">
              <a class="dropdown-item" href="/materia-matematica">Matemática</a>
              <a class="dropdown-item" href="/materia-fisica">Física</a>
              <a class="dropdown-item" href="/materia-quimica">Química</a>
              <a class="dropdown-item" href="/materia-biologia">Biologia</a>
              <a class="dropdown-item" href="/materia-geografia">Geografia</a>
              <a class="dropdown-item" href="/materia-literatura">Literatura</a>
              <a class="dropdown-item" href="/materia-historia">História</a>
              <a class="dropdown-item" href="/materia-portugues">Português</a>
            </div>
          </li>
        </ul>

        <!-- FORMULÁRIO 'PESQUISA' -->
        <form class="form-inline my-2 my-lg-0" method="post" action="/resultado">
          <input class="form-control mr-sm-2" type="text" name="buscar" placeholder="Pesquisar" aria-label="Pesquisa"/>
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit" value="ir">Pesquisar</button>
        </form>

      </div>
      <!-- /LINKS DA NAVBAR -->
    </nav>
    <!-- /NAVBAR -->

    <!-- CONTEÚDO DA PÁGINA -->
    <main role="main">    
        <!-- CONTAINER -->
        <div class="container">
            
            <!-- TÍTULO DA PÁGINA -->
            <h1>ESCOLHA SUA MATÉRIA</h1>
            <hr> 

            <!-- SEÇÃO - LINKS PARA MATÉRIAS -->
            <div class="link links-materias">
                <!-- LINHA -->
                <div class="row">
                    <!-- COLUNA -->
                    <div class="col-lg-4">
                        <a href="/materia-matematica"><img class="rounded-circle" src="/public/images/matematica.png" alt="Matemática"></a>
                        <a href="/materia-matematica"><h2>Matemática</h2></a>
                    </div>

                    <!-- COLUNA -->
                    <div class="col-lg-4">
                        <a href="/materia-fisica"><img class="rounded-circle" src="/public/images/fisica.png" alt="Física"></a>
                        <a href="/materia-fisica"><h2>Física</h2></a>
                    </div>

                    <!-- COLUNA -->
                    <div class="col-lg-4">
                        <a href="/materia-quimica"><img class="rounded-circle" src="/public/images/quimica.png" alt="Química"></a>
                        <a href="/materia-quimica"><h2>Química</h2></a>
                    </div>
                </div>
                <!-- /LINHA -->

                <br><br>

                <!-- LINHA -->
                <div class="row">
                    <!-- COLUNA -->
                    <div class="col-lg-4">
                        <a href="/materia-biologia"><img class="rounded-circle" src="/public/images/biologia.png" alt="Biologia"></a>
                        <a href="/materia-biologia"><h2>Biologia</h2></a>
                    </div>

                    <!-- COLUNA -->
                    <div class="col-lg-4">
                        <a href="/materia-geografia"><img class="rounded-circle" src="/public/images/geografia.png" alt="Geografia"></a>
                        <a href="/materia-geografia"><h2>Geografia</h2></a>
                    </div>

                    <!-- COLUNA -->
                    <div class="col-lg-4">
                        <a href="/materia-literatura"><img class="rounded-circle" src="/public/images/literatura.png" alt="Literatura"></a>
                        <a href="/materia-literatura"><h2>Literatura</h2></a>
                    </div>
                </div>
                <!-- /LINHA -->

                <br><br>

                <!-- LINHA -->
                <div class="row">
                    <!-- COLUNA -->
                    <div class="col-lg-6">
                        <a href="/materia-historia"><img class="rounded-circle" src="/public/images/historia.png" alt="Historia"></a>
                        <a href="/materia-historia"><h2>História</h2></a>
                    </div>
                    <!-- COLUNA -->
                    <div class="col-lg-6">
                        <a href="/materia-portugues"><img class="rounded-circle" src="/public/images/portugues.png" alt="Portugues"></a>
                        <a href="/materia-portugues"><h2>Língua<br>Portuguesa</h2></a>
                    </div>
                </div>

            </div>
            <!-- /SEÇÃO - LINKS PARA MATÉRIAS -->

            <hr class="linha-divisoria">
        </div>
        <!-- /CONTAINER -->

        <!-- RODAPÉ -->
        <footer class="container link">
            <p class="float-right"><a href="#">Voltar para Cima</a></p>
            <p>&copy; 2018 Nota1000, 3º ETIM INFORMÁTICA &middot; <a href="/sobre-nos">Sobre Nós</a></p>
        </footer>
        <!-- /RODAPÉ -->
    </main>
    <!-- /CONTEÚDO DA PÁGINA -->

    <!-- BOOTSTRAP JQUERY, POPPER & JAVASCRIPT -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="/public/bootstrap/js/bootstrap.min.js" crossorigin="anonymous"></script>
</body>
</html>