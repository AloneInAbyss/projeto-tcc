<?php

namespace Project\Controller;

class Controller
{
    public function index()
    {
        require './app/views/index.php';
    }

    public function biologia()
    {
        require './app/views/biologia.php';
    }
}
