<?php
    echo' <!-- Noturno -->
    <script>

    function start(){
        

        if (localStorage.getItem("n")==="desligado"||""){
            document.getElementById("luz").src = "/public/images/sol.png";
            document.body.style.backgroundColor = "#C5E6FF";
            localStorage.setItem("n", "desligado");
        }
        else if(localStorage.getItem("n")==="ligado")  {  
            document.getElementById("luz").src = "/public/images/lua.png";
            document.body.style.backgroundColor = "#142A34"; 
         }

    }     

       function noturno(){
           if (localStorage.getItem("n")==="desligado"){
              localStorage.setItem("n", "ligado");
              document.getElementById("luz").src = "/public/images/lua.png";
              document.body.style.backgroundColor = "#142A34";
              
           }
           else if(localStorage.getItem("n")==="ligado")  {  
               localStorage.setItem("n", "desligado");
               document.getElementById("luz").src = "/public/images/sol.png";
               document.body.style.backgroundColor = "#C5E6FF"; 
                 
           }

       }


    </script> ';
?>