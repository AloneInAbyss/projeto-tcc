<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- BOOTSTRAP CSS, ESTILOS PERSONALIZADOS -->
    <link rel="stylesheet" href="/public/bootstrap/css/bootstrap.min.css" crossorigin="anonymous">
    
    <!-- CSS -->
        <!-- CSS GERAL -->
        <link rel="stylesheet" href="/public/css/style.css">
        <!-- CSS DESSA PÁGINA ESPECÍFICA -->
        <link rel="stylesheet" href="/public/css/pagina-inicial.css">

    <!-- TÍTULO & ÍCONE DO SITE -->
    <title>NOTA 1000 - Página Inicial</title>
    <link rel="icon" href="/public/images/site-logo.png">

    <!-- Modo Noturno -->
    <?php require_once './public/scripts/noturno.php'; ?>
   
</head>
<body onload="start();">

    <!-- NAVBAR -->
    <?php require_once './public/scripts/navbar.php'; ?>

    <!-- CONTEÚDO DA PÁGINA -->
    <main role="main">    
        <!-- CONTAINER -->
        <div class="container">
            
            <!-- TÍTULO DA PÁGINA -->
            <h1 class="titulo-principal">ESCOLHA SUA MATÉRIA</h1>
            <hr> 

            <!-- SEÇÃO - LINKS PARA MATÉRIAS -->
            <div class="link links-materias">
                <!-- LINHA -->
                <div class="row">
                    <!-- COLUNA -->
                    <div class="col-lg-4">
                        <a href="/materia-matematica"><img class="rounded-circle" src="/public/images/matematica.png" alt="Matemática"></a>
                        <a href="/materia-matematica"><h2>Matemática</h2></a>
                        
                    </div>

                    <!-- COLUNA -->
                    <div class="col-lg-4">
                        <a href="/materia-fisica"><img class="rounded-circle" src="/public/images/fisica.png" alt="Física"></a>
                        <a href="/materia-fisica"><h2>Física</h2></a>
                    </div>

                    <!-- COLUNA -->
                    <div class="col-lg-4">
                        <a href="/materia-quimica"><img class="rounded-circle" src="/public/images/quimica.png" alt="Química"></a>
                        <a href="/materia-quimica"><h2>Química</h2></a>
                    </div>
                </div>
                <!-- /LINHA -->

                <br><br>

                <!-- LINHA -->
                <div class="row">
                    <!-- COLUNA -->
                    <div class="col-lg-4">
                        <a href="/materia-biologia"><img class="rounded-circle" src="/public/images/biologia.png" alt="Biologia"></a>
                        <a href="/materia-biologia"><h2>Biologia</h2></a>
                    </div>

                    <!-- COLUNA -->
                    <div class="col-lg-4">
                        <a href="/materia-geografia"><img class="rounded-circle" src="/public/images/geografia.png" alt="Geografia"></a>
                        <a href="/materia-geografia"><h2>Geografia</h2></a>
                    </div>

                    <!-- COLUNA -->
                    <div class="col-lg-4">
                        <a href="/materia-literatura"><img class="rounded-circle" src="/public/images/literatura.png" alt="Literatura"></a>
                        <a href="/materia-literatura"><h2>Literatura</h2></a>
                    </div>
                </div>
                <!-- /LINHA -->

                <br><br>

                <!-- LINHA -->
                <div class="row">
                    <!-- COLUNA -->
                    <div class="col-lg-6">
                        <a href="/materia-historia"><img class="rounded-circle" src="/public/images/historia.png" alt="Historia"></a>
                        <a href="/materia-historia"><h2>História</h2></a>
                    </div>
                    <!-- COLUNA -->
                    <div class="col-lg-6">
                        <a href="/materia-portugues"><img class="rounded-circle" src="/public/images/portugues.png" alt="Portugues"></a>
                        <a href="/materia-portugues"><h2>Língua<br>Portuguesa</h2></a>
                    </div>
                </div>

            </div>
            <!-- /SEÇÃO - LINKS PARA MATÉRIAS -->

            <hr class="linha-divisoria">
        </div>
        <!-- /CONTAINER -->

        <!-- RODAPÉ -->
        <?php require_once './public/scripts/rodape.php'; ?>
        
    </main>
    <!-- /CONTEÚDO DA PÁGINA -->

    <!-- BOOTSTRAP JQUERY, POPPER & JAVASCRIPT -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="/public/bootstrap/js/bootstrap.min.js" crossorigin="anonymous"></script>
</body>
</html>