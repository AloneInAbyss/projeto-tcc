<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- BOOTSTRAP CSS, ESTILOS PERSONALIZADOS -->
    <link rel="stylesheet" href="/public/bootstrap/css/bootstrap.min.css" crossorigin="anonymous">
    <!-- CSS -->
        <!-- CSS GERAL -->
        <link rel="stylesheet" href="/public/css/style.css">
        <!-- CSS DESSA PÁGINA ESPECÍFICA -->
        <link rel="stylesheet" href="/public/css/pagina-conteudo-materia.css">

    <!-- TÍTULO & ÍCONE DO SITE -->
    <title>NOTA 1000 - Página Inicial</title>
    <link rel="icon" href="/public/images/site-logo.png">

    <!-- Modo Noturno -->
    <?php require_once './public/scripts/noturno.php'; ?>
</head>
<body onload="start();">
    <!-- NAVBAR -->
    <?php require_once './public/scripts/navbar.php'; ?>

    <!-- CONTEÚDO DA PÁGINA -->
    <main role="main">    
        <!-- CONTAINER -->
        <div class="container marketing">

            <!-- BREADCRUMP -->
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/">Início</a></li>
                    <li class="breadcrumb-item"><a href="#">(Matéria)</a></li>
                    <li class="breadcrumb-item active" aria-current="page">(Tema)</li>
                </ol>
            </nav>

            <!-- TÍTULO DA PÁGINA -->
            <h1 class="titulo">(Nome da Matéria)</h1>
            <h3 class="text-muted">(Nome do Tema)</h3>
            <hr class="page-header">

            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-sm-8">
                        <p>Modelo de parágrafo um, lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor.</p>
                        <p>Segundo parágrafo lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor.</p>
                    </div>
                </div>

                <br><br>

                <div class="row">
                    <div class="col-sm-3">
                        <img class="rounded-circle mx-auto d-block" alt="Imagem" src="data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" width="160" height="160">
                        <br>
                    </div>
                    <div class="col-sm-9">
                        <p class="lead">Este é um subtítulo destacado.</p>
                        <p>Este é um texto descritivo para a imagem à esquerda. Um parágrafo aleatório: lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor</p>
                    </div>
                </div>

                <br><br>

                <div class="row justify-content-center">
                    <div class="col-sm-3">
                        <figure class="figure">
                            <img class="figure-img img-fluid rounded-square mx-auto d-block" alt="Imagem" src="data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" width="200" height="200">
                            <figcaption class="figure-caption text-center">Esta é a descrição da figura acima. Lorem ipsum dolor.</figcaption>
                        </figure>
                        <br>
                        
                    </div>
                    <div class="col-sm-6">
                        <p>Este é um texto descritivo para a imagem à esquerda, centralizado, em tamanho reduzido. Um parágrafo aleatório: lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor</p>
                    </div>
                </div>
            </div>

            <!-- CAIXA FLUTUANTE -->
            <div class="float div-ocultar">
                <p class="my-float">Quer testar seu conhecimento?</p>
                <br>
                <a href="/exercicios"><button type="button" class="btn btn-outline-danger button-float">Clique Aqui!</button></a>
            </div>
            

            <hr class="linha-divisoria">
        </div>
        <!-- /CONTAINER -->

        <!-- RODAPÉ -->
        <?php require_once './public/scripts/rodape.php'; ?>
    </main>
    <!-- /CONTEÚDO DA PÁGINA -->

    <!-- BOOTSTRAP JQUERY, POPPER & JAVASCRIPT -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="/public/bootstrap/js/bootstrap.min.js" crossorigin="anonymous"></script>
</body>
</html>