<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- BOOTSTRAP CSS, ESTILOS PERSONALIZADOS -->
    <link rel="stylesheet" href="/public/bootstrap/css/bootstrap.min.css" crossorigin="anonymous">
    <!-- CSS -->
        <!-- CSS GERAL -->
        <link rel="stylesheet" href="/public/css/style.css">
        <!-- CSS DESSA PÁGINA ESPECÍFICA -->
        <link rel="stylesheet" href="/public/css/pagina-materia.css">

    <!-- TÍTULO & ÍCONE DO SITE -->
    <title>NOTA 1000 - Página Inicial</title>
    <link rel="icon" href="/public/images/site-logo.png">
    
    <!-- Modo Noturno -->
    <?php require_once './public/scripts/noturno.php'; ?>
</head>
<body onload="start();">
    <!-- NAVBAR -->
    <?php require_once './public/scripts/navbar.php'; ?>

    <!-- CONTEÚDO DA PÁGINA -->
    <main role="main">    
        <!-- CONTAINER -->
        <div class="container marketing">

            <!-- BREADCRUMB -->
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/">Início</a></li>
                    <li class="breadcrumb-item"><a href="#">Matemática</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Sumário</li>
                </ol>
            </nav>

            <!-- TÍTULO DA PÁGINA -->
            <h1 class="titulo">Matemática</h1>
            <hr class="page-header">

            <!-- ACCORDION -->
            <div id="accordion">
                <!-- CARD -->
                <div class="card">
                    <!-- HEADER DO CARD -->
                    <div class="card-header" id="headingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            (Tema 1)
                            </button>
                        </h5>
                    </div>

                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                        <!-- BODY DO CARD -->
                        <div class="card-body">
                            <!-- LINHA -->
                            <div class="row">
                                <div class="col">
                                    <h3 class="text-center">Nome do Tema</h3>
                                </div>
                            </div>

                            <!-- LINHA -->
                            <div class="row espaco-row">
                                <div class="col">
                                    <div class="list-group">    
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 1</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 2</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 3</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 4</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 5</a>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="list-group">  
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 1</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 2</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 3</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 4</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 5</a>
                                    </div> 
                                </div>   
                            </div>

                        </div>
                        <!-- /BODY DO CARD -->
                    </div>
                </div>
                <!-- /CARD -->

                <!-- CARD -->
                <div class="card">
                    <!-- HEADER DO CARD -->
                    <div class="card-header" id="headingTwo">
                        <h5 class="mb-0">
                            <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            (Tema 2)
                            </button>
                        </h5>
                    </div>

                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                        <!-- BODY DO CARD -->
                        <div class="card-body">
                            <!-- LINHA -->
                            <div class="row">
                                <div class="col">
                                    <h3 class="text-center">Nome do Tema</h3>
                                </div>
                            </div>

                            <!-- LINHA -->
                            <div class="row espaco-row">
                                <div class="col">
                                    <p class="lead text-center">Subtema 2</p>
                                    <div class="list-group">  
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 1</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 2</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 3</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 4</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 5</a>
                                    </div> 
                                </div>
                                <div class="col">
                                    <p class="lead text-center">Subtema 2</p>
                                    <div class="list-group">  
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 1</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 2</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 3</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 4</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 5</a>
                                    </div> 
                                </div>
                            </div>
                        </div>
                        <!-- /BODY DO CARD -->
                    </div>
                </div>
                <!-- /CARD -->
                
                <!-- CARD -->
                <div class="card">
                    <!-- HEADER DO CARD -->
                    <div class="card-header" id="headingThree">
                        <h5 class="mb-0">
                            <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            (Tema 3)
                            </button>
                        </h5>
                    </div>

                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                        <!-- BODY DO CARD -->
                        <div class="card-body">
                            <!-- LINHA -->
                            <div class="row">
                                <div class="col">
                                    <h3 class="text-center">Nome do Tema</h3>
                                </div>
                            </div>

                            <!-- LINHA -->
                            <div class="row espaco-row">
                                <div class="col">
                                    <p class="lead text-center">Subtema 1</p>
                                    <div class="list-group">  
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 1</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 2</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 3</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 4</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 5</a>
                                    </div> 
                                </div>
                                <div class="col">
                                    <p class="lead text-center">Subtema 2</p>
                                    <div class="list-group">  
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 1</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 2</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 3</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 4</a>
                                        <a href="#" class="list-group-item list-group-item-action">Matéria 5</a>
                                    </div> 
                                </div>
                            </div>
                            
                            <!-- LINHA -->
                            <div class="row espaco-row">
                                <div class="col">
                                    <p class="lead text-center">Subtema 3</p>
                                    <div class="list-group">  
                                    <a href="#" class="list-group-item list-group-item-action">Matéria 1</a>
                                    <a href="#" class="list-group-item list-group-item-action">Matéria 2</a>
                                    <a href="#" class="list-group-item list-group-item-action">Matéria 3</a>
                                    <a href="#" class="list-group-item list-group-item-action">Matéria 4</a>
                                    <a href="#" class="list-group-item list-group-item-action">Matéria 5</a>
                                </div> 
                                </div>
                                <div class="col">
                                    <p class="lead text-center">Subtema 4</p>
                                    <div class="list-group">  
                                    <a href="#" class="list-group-item list-group-item-action">Matéria 1</a>
                                    <a href="#" class="list-group-item list-group-item-action">Matéria 2</a>
                                    <a href="#" class="list-group-item list-group-item-action">Matéria 3</a>
                                    <a href="#" class="list-group-item list-group-item-action">Matéria 4</a>
                                    <a href="#" class="list-group-item list-group-item-action">Matéria 5</a>
                                    </div> 
                                </div>
                            </div>
                        </div>
                        <!-- /BODY DO CARD -->
                    </div>
                </div>
                <!-- /CARD -->
            </div>
            <!-- /ACCORDION -->

            <hr class="linha-divisoria">
        </div>
        <!-- /CONTAINER -->

        <!-- RODAPÉ -->
        <?php require_once './public/scripts/rodape.php'; ?>
    </main>
    <!-- /CONTEÚDO DA PÁGINA -->

    <!-- BOOTSTRAP JQUERY, POPPER & JAVASCRIPT -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="/public/bootstrap/js/bootstrap.min.js" crossorigin="anonymous"></script>
</body>
</html>