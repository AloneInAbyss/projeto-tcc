<?php
// Declaração dos namespaces dos controladores e instanciação dos objetos
use Project\Controller\Controller;
$Controller = new Controller();